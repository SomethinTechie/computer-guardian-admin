<div class="" style="width: 400px">
    <div class="modal-header bb1">
        <strong>ADD CUSTOMER</strong>
    </div>
    <form action="#" style="padding: 20px 30px;">
        <div class="form-group">
            <label for="name">Name</label>
            <div class="input-group">
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter customer name...">
            </div>
        </div>
        <div class="form-group">
            <label for="name">Email</label>
            <div class="input-group">
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter email address...">
            </div>
        </div>
        <div class="form-group">
            <label for="name">Mobile number</label>
            <div class="input-group no-borders">
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter mobile number...">
            </div>
        </div>
    </form>
    <div class="btns">
        <a href="#" class="std-btn default">ADD</a>
        <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})">Cancel</a>
    </div>
</div>