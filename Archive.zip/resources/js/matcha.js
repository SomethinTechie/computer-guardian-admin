function handleBrandChange(req) {
    console.log('selectedBrand')
}

console.log('matcha js')