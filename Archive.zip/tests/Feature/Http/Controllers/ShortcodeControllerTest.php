<?php

namespace Tests\Feature\Http\Controllers;

use App\Models\Campaign;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use JMac\Testing\Traits\AdditionalAssertions;
use Tests\TestCase;
use App\Models\User;
use App\Models\Shortcode;
use App\Models\CampaignShortcode;

/**
 * @see \App\Http\Controllers\CampaignController
 */
class ShortcodeControllerTest extends TestCase
{
    use AdditionalAssertions, RefreshDatabase, WithFaker;

    public function test_create_shortcode() {

        $user = User::factory()->create();

        $type = $this->faker->word;
        $status = $this->faker->word;
        $code = $this->faker->word;

        $formData = [
            'type' => $type,
            'status' => $status,
            'code' => $code,
        ];

        $this->actingAs($user)->post(route('shortcode.store',), $formData);
        $this->assertDatabaseHas('shortcodes', $formData);
    }

    public function test_update_shortcode() {

        $user = User::factory()->create();
        $shortcode = Shortcode::factory()->create();

        $type = $this->faker->word;
        $status = $this->faker->word;
        $code = $this->faker->word;

        $formData = [
            'type' => $type,
            'status' => $status,
            'code' => $code,
        ];

        $this->actingAs($user)->put(route('shortcode.update',['shortcode' => $shortcode->id]), $formData);
        $this->assertDatabaseHas('shortcodes', $formData);
    }

    public function test_delete_shortcode() {

        $user = User::factory()->create();
        $shortcode = Shortcode::factory()->create();

        $shortcodeId = [
            'id' => $shortcode->id,
        ];

        $this->actingAs($user)->delete(route('shortcode.destroy',['shortcode' => $shortcode->id]));
        $this->assertDatabaseMissing('shortcodes', $shortcodeId);
    }
}
