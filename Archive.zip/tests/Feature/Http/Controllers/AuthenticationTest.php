<?php

namespace Tests\Feature;

use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\URL;
use Illuminate\Auth\Events\Verified;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_authentication()
    {
        $response = $this->get('/home');
        $response->assertStatus(302);
        $response->assertRedirect('login');

        $user = User::factory()->create();
        $response = $this->actingAs($user)->get('/home');
        $response = $this->actingAs($user)->get('/campaign/create');
        $response->assertOk();
    }
}