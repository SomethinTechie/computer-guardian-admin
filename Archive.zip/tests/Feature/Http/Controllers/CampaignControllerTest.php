<?php

namespace Tests\Feature\Http\Controllers;

use App\Models\Campaign;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use JMac\Testing\Traits\AdditionalAssertions;
use Tests\TestCase;
use App\Models\User;
use App\Models\Shortcode;
use App\Models\CampaignShortcode;

/**
 * @see \App\Http\Controllers\CampaignController
 */
class CampaignControllerTest extends TestCase
{
    use AdditionalAssertions, RefreshDatabase, WithFaker;

    /**
     * @test
     */
    public function test_create_displays_view()
    {
        $response = $this->get(route('campaign.create'));

        $response->assertOk();
        $response->assertViewIs('campaign.create');
    }

    /**
     * @test
     */
    public function test_show_returns_campaign_and_associated_shortcodes_in_json()
    {
        $user = User::factory()->create();
        $this->actingAs($user);

        $shortcode = ShortCode::factory()->create();
        $campaign = Campaign::factory()->create();
        $campaign->shortcodes()->attach($shortcode->id);

        $response = $this->json('GET', route('campaign.show', ['campaign' => $campaign->id]));

        $response->assertStatus(200);
        $response->assertViewIs('campaign.show');
        $response->assertViewHas('campaign', $campaign);
    }

    /**
     * @test
     */
    public function test_update_campaign_status_and_returns_json()
    {
        $user = User::factory()->create();
        $this->actingAs($user);

        $campaign = Campaign::factory()->create();

        $response = $this->json('POST', route('campaign-update.status', ['campaign' => $campaign->id]), [
            'status' => 'Approved',
        ]);

        $response->assertStatus(200);
        $response->assertJson([
            'message' => $campaign->CampaignName . ' Status updated successfully to Approved',
            'campaign' => [
                'id' => $campaign->id,
                'status' => 'Approved',
            ],
        ]);

        $this->assertDatabaseHas('campaigns', [
            'id' => $campaign->id,
            'status' => 'Approved',
        ]);
        // $response->dump($response);
    }

    /**
     * @test
     */
    public function test_destroy_campaign_and_associated_shortcodes()
    {
        $user = User::factory()->create();
        $this->actingAs($user);

        $shortcode = ShortCode::factory()->create(['code' => '8901']);
        $campaign = Campaign::factory()->create();
        $campaign->shortcodes()->attach($shortcode->id);

        $response = $this->json('DELETE', route('campaign.destroy', ['campaign' => $campaign->id]));

        $response->assertStatus(200);
        $response->assertJson([
            'message' => 'Campaign deleted successfully',
        ]);

        $this->assertDatabaseMissing('campaigns', [
            'id' => $campaign->id,
        ]);
        $this->assertDatabaseMissing('campaign_shortcodes', [
            'shortcode_id' => $shortcode->id,
            'campaign_id' => $campaign->id,
        ]);
    }

    /**
     * @test
     */
    public function test_pending_returns_view_with_pending_campaigns()
    {
        $user = User::factory()->create();
        $this->actingAs($user);

        $pendingCampaign = Campaign::factory()->create(['status' => 'Pending']);
        $approvedCampaign = Campaign::factory()->create(['status' => 'Approved']);

        $response = $this->get(route('campaign.pending'));

        $response->assertStatus(200);
        $response->assertViewIs('campaign.pending');
        $response->assertViewHas('campaigns', function ($campaigns) use ($pendingCampaign, $approvedCampaign) {
            return $campaigns->contains($pendingCampaign) && !$campaigns->contains($approvedCampaign);
        });
    }
    public function campaign_update()
    {
        $user = User::factory()->create();
        $campaign = Campaign::factory()->create();

        $brand_name = $this->faker->word;
        $product_name = $this->faker->word;
        $from_date = $this->faker->date();
        $to_date = $this->faker->date();
        $terms_file = $this->faker->word;
        $terms_link = $this->faker->word;

        $newData = [
            'brand_name' => $brand_name,
            'product_name' => $product_name,
            'from_date' => $from_date,
            'to_date' => $to_date,
        ];

        $this->actingAs($user)->put(route('campaign.update',['campaign' => $campaign->id]), $newData);
        $this->assertDatabaseHas('campaigns', $newData);
    }
    public function test_campaign_form_visible()
    {
        $user = User::factory()->create();
        $response = $this->actingAs($user)->get('/campaign/create');
        $this->assertStringContainsString('name="brand_name"', $response->getContent());
        $this->assertStringContainsString('name="product_name"', $response->getContent());
        $this->assertStringContainsString('name="to_date"', $response->getContent());
        $this->assertStringContainsString('name="from_date"', $response->getContent());
    }
}
