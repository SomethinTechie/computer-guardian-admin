<?php

namespace Tests\Unit;

use Tests\TestCase;

class CheckViews extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function test_welcome_view()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function test_login_view()
    {
        $response = $this->get('/login');

        $response->assertStatus(200);
    }
    
    public function test_home_view()
    {
        $response = $this->get('/home');

        $response->assertStatus(302);
    }
}