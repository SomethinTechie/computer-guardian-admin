<?php

return [
    'mail_recipients' => [
        'publish' => [
            'production' => env('PROD_EMAIL'),
            'staging' => env('DEV_EMAIL'),
            'local' => env('DEV_EMAIL'),
        ]
    ]
];
