<?php

return [
    'dashboards' => env('DASHBOARDS_LINK', 'default_value'),
    'checkers_draws_api' => env('CHECKERS_DRAWS_API', 'default_value'),
    'checkers_draws_token' => env('CHECKERS_DRAWS_API_TOKEN', 'default_value'),
    'shoprite_draws_api' => env('SHOPRITE_DRAWS_API', 'default_value'),
    'shoprite_checkers_draws_api' => env('SHORPRITE_CHECKERS_DRAWS_API', 'default_value'),
    'shoprite_draws_token' => env('SHOPRITE_DRAWS_API_TOKEN', 'default_value'),

];
