# Project Name

A brief description of the project.

## Table of Contents

-   [Installation](#installation)

## Installation

php artisan migrate
php artisan db:seed --class=Country
php artisan db:seed --class=EposCampaignReward
php artisan db:seed --class=EposCampaignType
php artisan db:seed --class=EposCmapignDraw

instance https://github.com/YonderMedia/shoprite-sencha-v2
branch 44623-dev
Deploy staging
note please check readme for more information

Mahlatse;
add consommelpro connection if brand selected is Shoprite or Shoprite & Checkers (Only to pinotage if ONLY checkers)
save updates end_date in consommelpro/pinotage DB when extended in Epos
Remove hardcoded Campaign IDs - downloadCSV, generateWinnersCSV, storeWeeklyDrawDates
Manual Draws;

-   https://scstagepinotage-checkers.scprod.yonder.cloud/api/winnerdraw
-   https://scstageconsommelpro-shoprite.scprod.yonder.cloud/api/winnerdraw

{
"campaign_id": "123",
"primary_winners": "20",
"secondary_winners":20
}

sudo /Applications/XAMPP/xamppfiles/bin/apachectl start
# computer_guardian_admin
