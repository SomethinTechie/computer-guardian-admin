<div class="overview-card">
    <div class="col-md-3">
        <div class="overview-card-insight" style="border-left: none">
            <h4 class="pc">Quick overview of <br>the activities</h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="overview-card-insight">
            <i class="bi bi-easel2 pc"></i><br><br>
            Live campaigns <br><br>
            <h4><?php echo e($activeCampaignsCount); ?></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="overview-card-insight">
            <i class="bi bi-arrow-clockwise pc"></i><br><br>
            Pending campaigns <br><br>
            <h4><?php echo e($pendingCampaignsCount); ?></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="overview-card-insight">
            <i class="bi bi-upc pc"></i><br><br>
            Closed campaigns <br><br>
            <h4><?php echo e($closedCampaignsCount); ?></h4>
        </div>
    </div>
</div>
<div class="">
    <div class="header">RECENT ACTIVITY</div>
    <?php if(count($activities) > 0): ?>
    <table>
        <th>Action</th>
        <th>Time</th>
        <th>User</th>
        <div class="list shade">
            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($activity->description); ?></td>
                    <td><?php echo e($activity->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($activity->user->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </table>
    <div class="row mt-5">
        <?php echo e($activities->links('pagination::bootstrap-4')); ?>

    </div>
    <?php else: ?>
        <div class="list-item" style="padding-left: 5px;pointer-events: none">
            <div>No recent activity</div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/dashboard.blade.php ENDPATH**/ ?>