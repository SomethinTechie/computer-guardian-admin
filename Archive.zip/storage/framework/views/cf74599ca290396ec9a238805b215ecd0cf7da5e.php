<?php $__env->startSection('content'); ?>
    <div class="side-navigation">
        <div class="header pbc">
            
            <img src="<?php echo e(asset('logos/rainmaker-og.png')); ?>" width="100" alt="">
        </div>
        <div class="nav-sect">PRIMARY</div>
        <a href="#" onclick="getView({'url':'<?php echo e(route('dashboard')); ?>','view':'ajax-view'})" class="active"><i
                class="mr-2 bi bi-house pc"></i> Overview</a>
        <a href="<?php echo e(config('urls.dashboards')); ?>" target="_blank" class=""><i class="mr-2 bi bi-bar-chart pc"></i>
            Dashboards</a>
        <a href="#" onclick="getView({'url':'<?php echo e(route('campaign.index')); ?>','view':'ajax-view'})"><i
                class="mr-2 bi bi-layers pc"></i> View Campaigns</a>
        <a href="#" onclick="getView({'url':'<?php echo e(route('campaign.pending')); ?>','view':'ajax-view'})"><i
                class="mr-2 bi bi-calendar2 pc"></i> Pending</a>
        <a href="#" onclick="getView({'url':'<?php echo e(route('campaign.closed')); ?>','view':'ajax-view'})"><i
                class="mr-2 bi bi-calendar2-x pc"></i> Closed</a>
        <a href="#" onclick="getView({'url':'<?php echo e(route('campaign.create')); ?>','view':'ajax-view'})"><i
                class="mr-2 bi bi-calendar2-plus pc"></i> Create campaign</a>
    </div>
    <div class="main-dashboard-view">
        <div class="header space-between pbc">
            <form id="globalSearchForm" action="#" class="search-form col-md-4">
                <i class="bi bi-search mr-2"></i><input type="text" id="globalSearch"
                    placeholder="Search campaign name or hybris ID..." style="width: calc(100% - 50px);">
            </form>
            <div class="right">
                <!-- <span class=""><?php echo e(Auth::user()->name); ?></span> -->
                <a href="#"><i class="bi bi-bell mr-3" style="color: #fff"></i></a>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                <!-- <div class="avatar"></div> -->
            </div>
        </div>
        <div class="ajax-view">
            <div class="overview-card">
                <div class="col-md-4">
                    <div class="overview-card-insight">
                        <span>
                            <i class="bi bi-easel2 pc"></i><br><br>
                            Live campaigns <br><br>
                            <h4><?php echo e($activeCampaignsCount); ?></h4>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="overview-card-insight">
                        <span>
                            <i class="bi bi-arrow-clockwise pc"></i><br><br>
                            Pending campaigns <br><br>
                            <h4><?php echo e($pendingCampaignsCount); ?></h4>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="overview-card-insight">
                        <span>
                            <i class="bi bi-x-lg pc"></i><br><br>
                            Closed campaigns <br><br>
                            <h4><?php echo e($closedCampaignsCount); ?></h4>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-md-12" style="height: 100px!important;">
                <div class="header">RECENT ACTIVITY</div>
                <?php if(count($activities) > 0): ?>
                    <table>
                        <th>Action</th>
                        <th>Time</th>
                        <th>User</th>
                        <div class="list shade">
                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($activity->description); ?></td>
                                    <td><?php echo e($activity->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($activity->user->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </table>

                    <div class="row mt-3" style="padding: 0 20px">
                        <?php echo e($activities->links('pagination::bootstrap-4')); ?>

                    </div>
                <?php else: ?>
                    <div class="list-item" style="padding-left: 5px;pointer-events: none">
                        <div>No recent activity</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="modal-wrapper animated fadeIn">

        <div id="confirmDeleteModal" class="body animated fadeInUp" style="width: 300px">
            <div class="modal-header bb1"><strong>DELETE PRIZE</strong></div>
            <div class="btns mt-3">
                <a href="#" class="std-btn default">Continue</a>
                <a href="#" class="std-btn default" onclick="closeModal({'modalId':'confirmDeleteModal'})">Cancel</a>
            </div>
        </div>

        <div id="ussdShortcodeModal" class="body animated fadeInUp" style="width: 400px">
            <div class="modal-header bb1"><strong>SELECT USSD PREFIX BELOW</strong></div>
            <div class="form-group" style="padding: 20px 30px">
                <div class="input-group">
                    <select name="" id="ussdCodeValue" onchange="checkPrefix({'type':'USSD'})" data-type="USSD">
                        <option value="">Select USSD prefix</option>
                        <?php $__currentLoopData = $shortcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($shortcode->type == 'USSD' && count($shortcode->campaigns) == 0): ?>
                                <option data-shortcode_id="<?php echo e($shortcode->id); ?>" value="<?php echo e($shortcode->code); ?>">
                                    <?php echo e($shortcode->code); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="Create new shortcode">Create new shortcode</option>
                    </select>
                </div>

                <div id="ussdCustomCode" class="input-group mt-1" style="border: none">
                    <form id="newUssdCodeForm" action="<?php echo e(route('shortcode.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group" style="padding-right: 20px">
                            <select name="type" id=""
                                onchange="updatePlaceHolder({'inputId':'ussdShortcode'})">
                                <option value="USSD">USSD</option>
                            </select>
                        </div>
                        <div class="input-group mt-1 mb-1" style="padding-right: 20px">
                            <select name="status" id="">
                                <option value="Select status">Select status</option>
                                <option value="Disabled">Disabled</option>
                                <option value="Active">Active</option>
                            </select>
                        </div>
                        <div class="input-group">
                            <input id="ussdShortcode" name="code" type="text" placeholder="Enter USSD code">
                        </div>
                    </form>
                </div>
            </div>
            <div class="btns" style="padding: 0 30px 20px 30px">
                <a href="#" class="std-btn default"
                    onclick="assignCode({'Type':'USSD','targetInput':'ussdCodeValue','formId':'newUssdCodeForm'})">Continue</a>
                <a href="#" class="std-btn default"
                    onclick="closeModal({'modalId':'ussdShortcodeModal'})">Cancel</a>
            </div>
        </div>

        <!-- Dynamic modal view -->
        <div id="updateModal" class="body animated fadeInUp"></div>
        <div id="ajaxModal" class="body animated fadeInUp"></div>

        <div id="campaignDrawModal" class="body animated fadeInUp">
            <div class="" style="width: 600px">
                <div class="modal-header bb1"><strong>CAMPAIGN DRAW DATES</strong></div>
                <form id="campaignDrawDates" method="post" action="" class="col-md-12"
                    style="display: flex;padding: 25px">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <table id="draw-dates"></table>
                        <div class="btns" style="padding: 20px 0 0 0">
                            <a href="#" class="std-btn default"
                                onclick="submitForm({'formId':'campaignDrawDates', 'url':'<?php echo e(route('campaign.weekly-draw-dates.store')); ?>','method':'POST','resDataContainer':'ajaxInputs','modalId':'campaignDrawModal'})">SAVE
                                & CONTINUE</a>
                            <a href="#" class="std-btn default"
                                onclick="closeModal({'modalId':'campaignDrawModal','clearElm':'draw-dates'})">CANCEL</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div id="whatsappShortcodeModal" class="body animated fadeInUp" style="width: 400px">
            <div class="modal-header bb1"><strong>SELECT WHATSAPP KEYWORD BELOW</strong></div>
            <div class="form-group" style="padding: 20px 30px">
                <div class="input-group">
                    <select name="" id="whatsappCodeValue" onchange="checkPrefix({'type':'Whatsapp'})"
                        data-type="Whatsapp">
                        <option value="">Select Whatsapp prefix</option>
                        <?php $__currentLoopData = $shortcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($shortcode->type == 'Whatsapp' && count($shortcode->campaigns) == 0): ?>
                                <option value="<?php echo e($shortcode->code); ?>"><?php echo e($shortcode->code); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="Create new shortcode">Create new shortcode</option>
                    </select>
                </div>

                <div id="whatsappCustomCode" class="input-group mt-1" style="border: none">
                    <form id="newWhatsappCodeForm" action="<?php echo e(route('shortcode.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group" style="padding-right: 20px">
                            <select value="whatsapp" name="type" id=""
                                onchange="updatePlaceHolder({'inputId':'whatsappKeyword'})">
                                <option value="Whatsapp">Whatsapp</option>
                            </select>
                        </div>
                        <div class="input-group mt-1 mb-1" style="padding-right: 20px">
                            <select name="status" id="">
                                <option value="Select status">Select status</option>
                                <option value="Disabled">Disabled</option>
                                <option value="Active">Active</option>
                            </select>
                        </div>
                        <div class="input-group">
                            <input id="whatsappKeyword" name="code" type="text"
                                placeholder="Enter whatsapp keyword">
                        </div>
                    </form>
                </div>
            </div>
            <div class="btns" style="padding: 0 30px 20px 30px">
                <a href="#" class="std-btn default"
                    onclick="assignCode({'Type':'Whatsapp','targetInput':'whatsappCodeValue','formId':'newWhatsappCodeForm'})">Continue</a>
                <a href="#" class="std-btn default"
                    onclick="closeModal({'modalId':'whatsappShortcodeModal'})">Cancel</a>
            </div>
        </div>

        <div id="addQuestionsModal" class="body animated fadeInUp" style="width: 500px">
            <div class="modal-sect active">
                <div class="modal-header bb1"><strong>ADD A QUESTION</strong></div>
                <form id="questionForm" action="<?php echo e(route('question.store')); ?>" method="POST"
                    style="padding: 25px 30px">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" name="name" style="background: transparent"
                            placeholder="Enter name...">
                    </div>
                    <div class="input-group mt-1">
                        <select name="type">
                            <option value="Select type">Select type</option>
                            <option value="Text input">Text input</option>
                            <option value="Multi-choice">Multi-choice</option>
                        </select>
                    </div>
                    <div class="input-group mt-1">
                        <textarea name="question" rows="3" placeholder="Enter question..."></textarea>
                    </div>
                </form>

                <div class="btns" style="padding: 0 30px 20px 30px">
                    <a href="#" class="std-btn default"
                        onclick="submitForm({'formId':'questionForm', 'url':'<?php echo e(route('question.store')); ?>','modalSect':'question-success','resView':'addQuestionsModal','method':'POST'})">ADD
                        QUESTION</a>
                    <a href="#" class="std-btn default"
                        onclick="closeModal({'modalId':'addQuestionsModal'})">CANCEL</a>
                </div>
            </div>
            <div id="question-success" class="modal-sect">
                <div class="modal-header bb1"><strong>QUESTION SUCCESSFULLY ADDED</strong></div>
                <div class="btns" style="padding:  20px 30px">
                    <a href="#" class="std-btn default"
                        onclick="prevModalSect({'modalSect':'question-success'})">ADD ANOTHER</a>
                    <a href="#" class="std-btn default"
                        onclick="closeModal({'modalId':'addQuestionsModal','modalSect':'question-success'})">CANCEL</a>
                </div>
            </div>
        </div>

        <div id="add-shortcode-modal" class="body animated fadeInUp add-shortcode-modal"
            style="width: 400px;background: #f9f9f9">
            <div class="modal-sect active">
                <div class="modal-header bb1 bgw" style="border-radius: 10px 10px 0 0"><strong>ADD SHORTCODE</strong>
                </div>
                <form id="shortcodeForm" method="POST" action="<?php echo e(route('shortcode.store')); ?>" class="std-padding"
                    style="padding: 20px 30px">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="input-group" style="padding-right: 20px">
                            <select name="type" id=""
                                onchange="updatePlaceHolder({'inputId':'shortcodeInput'})">
                                <option value="">Select type</option>
                                <option value="ussd">USSD</option>
                                <option value="whatsapp">Whatsapp</option>
                            </select>
                        </div>
                        <div class="error" data-name="type field"></div>
                        <div class="input-group mt-1 mb-1" style="padding-right: 20px">
                            <select name="status" id="">
                                <option value="">Select status</option>
                                <option value="Disabled">Disabled</option>
                                <option value="Active">Active</option>
                            </select>
                        </div>
                        <div class="error mt-1" data-name="status field"></div>
                        <div class="input-group">
                            <input id="shortcodeInput" name="code" type="text" placeholder="...">
                        </div>
                        <div class="error" data-name="code field"></div>
                    </div>
                </form>
                <div class="btns" style="padding: 0 30px 20px 30px">
                    <a href="#" class="std-btn default"
                        onclick="submitForm({'formId':'shortcodeForm', 'url':'<?php echo e(route('shortcode.store')); ?>', 'resView':'add-shortcode-modal','modalSect':'shortcode-success','method':'POST'})">SAVE
                        CODE</a>
                    <a href="#" class="std-btn default"
                        onclick="closeModal({'modalId':'add-shortcode-modal'})">Cancel</a>
                </div>
            </div>
            <div id="shortcode-success" class="modal-sect">
                <div class="modal-header bb1"><strong>SHORTCODE ADDED</strong></div>
                <div class="btns" style="padding:  20px 30px">
                    <a href="#" class="std-btn default"
                        onclick="prevModalSect({'modalSect':'shortcode-success'})">ADD ANOTHER</a>
                    <a href="#" class="std-btn default"
                        onclick="closeModal({'modalId':'add-shortcode-modal','modalSect':'shortcode-success'})">CANCEL</a>
                </div>
            </div>
        </div>

        <div id="edit-shortcode-modal" class="body animated fadeInUp add-shortcode-modal"
            style="width: 400px;background: #f9f9f9">

        </div>

    </div>
    <div id="search-loading" class="search-loading">
        <div style="color: #fff">Searching...</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/home.blade.php ENDPATH**/ ?>