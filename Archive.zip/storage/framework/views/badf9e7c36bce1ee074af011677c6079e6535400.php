<div>
    <div class="modal-sect active" style="width: 350px">
        <div class="modal-header bb1"><strong>CONFIRM ACTION</strong></div>
        <form id="createDrawModal" method="post" action="<?php echo e(route('update.campaign',[$campaign->id])); ?>" class="col-md-12"
            style="display: flex;padding: 0 25px 25px 25px">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
                <label for="" class="text14">Are you sure? Press yes to notify YONDER  to move  <strong><?php echo e($campaign->title); ?></strong> campaign into LIVE state.</label>
                <div class="btns live-btns" style="padding: 0">
                    <a href="#" class="std-btn default" onclick="confirmAction({'url':'<?php echo e(route('campaign.send.go.live.mail',[$campaign->id])); ?>', 'resView':'confirmation-seccuess','modalSect':'confirmation-seccuess','method':'GET'})">YES</a>
                    <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})">NO</a>
                </div>
            </div>
        </form>
    </div>
    <div id="confirmation-seccuess" class="modal-sect confirmation-seccuess" style="width: 350px">
        <div class="modal-header bb1"><strong>EMAIL SENT SUCCESSFULLY</strong></div>

        <div class="btns" style="padding: 20px 30px 20px 30px">
            <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})" style="border-radius: 4px">DONE</a>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/modals/confirm-go-live-modal.blade.php ENDPATH**/ ?>