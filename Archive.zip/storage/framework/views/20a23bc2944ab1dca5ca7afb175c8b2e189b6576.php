<div class="header space-between" style="border-bottom: none;">
    <h5>Shortcodes</h5>
    <a href="#" class="std-btn-sm" onclick="openModal({'modalId':'add-shortcode-modal'})">ADD SHORTCODE</a>
</div>

<div class="col-md-12 mt-2 std-padding-x">
    
    <div class="">
        <div class="list">
            <?php if(count($shortcodes) > 0): ?>
                <div class="list-header mt-5 mb-3"
                    style="display: flex;align-items: center;justify-content: space-between">
                    <div class="" style="width: 20%">Campaign Type</div>
                    <div class="" style="width: 20%">Brand</div>
                    <div class="" style="width: 20%">Campaign name</div>
                    <div class="" style="width: 20%">Campaign dates</div>
                    <div class="" style="width: 20%">Prefix/Shortcode/ID</div>
                    <div class="" style="width: 50px"></div>
                </div>
                <div class="scrollview">
                    <?php $__currentLoopData = $shortcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($shortcode->campaignShortcode): ?>
                            <div class="list-item"
                                style="display: flex;align-items: center;justify-content: space-between;">
                                <div style="width: 20%"><?php echo e($shortcode->type); ?></div>
                                <div style="width: 20%"><?php echo e($shortcode->campaignShortcode->campaign->brand_name); ?></div>
                                <div style="width: 20%"><?php echo e($shortcode->campaignShortcode->campaign->campaign_name); ?>

                                </div>
                                <div style="width: 20%"><strong>From</strong>
                                    <?php echo e($shortcode->campaignShortcode->campaign->from_date); ?> <strong>to</strong>
                                    <?php echo e($shortcode->campaignShortcode->campaign->to_date); ?></div>
                                <div style="width: 20%"><?php echo e($shortcode->code); ?></div>
                                <div class="drop-down-opts-btn"
                                    style="padding-right: 10px;position: relative;width: 50px">
                                    <!-- <a href="#" class="std-btn-sm f-right">Delete</a>
                                <a href="#" class="std-btn-sm f-right">Disable</a> -->
                                    <i class="bi bi-three-dots-vertical" style="float: right;margin-right: 5px"></i>
                                    <span class="drop-down-opts">
                                        <li style="pointer-events: none"
                                            onclick="openModal({'modalId':'confirmDeleteModal', 'modalType':'delete', 'title':'DELETE SHORTCODE #<?php echo e($shortcode->code); ?>','nextUri':'<?php echo e(route('shortcode.destroy', ['shortcode' => $shortcode->id])); ?>'})">
                                            Delete <i class="bi bi-trash mr20"></i> </li>
                                    </span>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="list-item"
                                style="display: flex;align-items: center;justify-content: space-between;">
                                <div style="width: 20%"><?php echo e($shortcode->type); ?></div>
                                <div style="width: 20%">Unassigned</div>
                                <div style="width: 20%">Unassigned</div>
                                <div style="width: 20%">Unassigned</div>
                                <div style="width: 20%"><?php echo e($shortcode->code); ?></div>
                                <div class="drop-down-opts-btn"
                                    style="padding-right: 10px;position: relative;width: 50px">
                                    <i class="bi bi-three-dots-vertical" style="float: right;margin-right: 5px"></i>
                                    <span class="drop-down-opts">
                                        <li
                                            onclick="openModal({'modalId':'confirmDeleteModal', 'modalType':'delete', 'title':'DELETE SHORTCODE #<?php echo e($shortcode->code); ?>','nextUri':'<?php echo e(route('shortcode.destroy', ['shortcode' => $shortcode->id])); ?>'})">
                                            Delete <i class="bi bi-trash mr20"></i> </li>
                                    </span>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="mt-3 message" style="padding: 0"><span>No shortcodes added yet.</span></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaignShortcode/index.blade.php ENDPATH**/ ?>