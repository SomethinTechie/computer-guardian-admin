<div style="width: 400px">
    <div class="modal-sect active">
        <div class="modal-header bb1"><strong>CAMPAIGN OPTIONS</strong></div>
        <div class="list" style="padding: 20px 0;float:left">
            <?php
                $end_date = \Carbon\Carbon::parse($campaign->end_date);
            ?>
            <?php if($end_date->isPast()): ?>
                <div class="message" style="padding: 0 40px;text-align: center">Options not available for campaigns that are closed.</div>
            <?php else: ?>
                <div class="list-item space-between bb1" style="padding: 0 30px"
                    onclick="processUpdate({'modalSect':'status-update-success','status':'Approved','url':'<?php echo e(route('campaign-update.status', [$campaign->id])); ?>','formId':'updateCampaignStatusForm'})">
                    Approve campaign <i class="bi bi-check-lg"></i>
                </div>
                <div class="list-item space-between bb1" style="padding: 0 30px"
                    onclick="processUpdate({'modalSect':'status-update-success','status':'Disabled','url':'<?php echo e(route('campaign-update.status', [$campaign->id])); ?>','formId':'updateCampaignStatusForm'})">
                    Disable campaign <i class="bi bi-pause" style="font-size: 25px;margin-right: -5px"></i>
                </div>
                <div class="list-item space-between" style="padding: 0 30px"
                    onclick="processUpdate({'modalSect':'status-update-success','status':'Closed','url':'<?php echo e(route('campaign-update.status', [$campaign->id])); ?>','formId':'updateCampaignStatusForm'})">
                    Close campaign <i class="bi bi-x-lg"></i>
                </div>
                <form id="updateCampaignStatusForm" action="<?php echo e(route('campaign-update.status', [$campaign->id])); ?>"
                    method="post">
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>
        </div>

        <div class="btns" style="padding: 0 30px 20px 30px">
            <!-- <a href="#" class="std-btn default" onclick="assignCode({'Type':'Whatsapp','targetInput':'whatsappCodeValue'})">Continue</a> -->
            <a href="#" class="std-btn default" onclick="closeModal({'modalId':'updateModal'})"
                style="border-radius: 4px">Cancel</a>
        </div>
    </div>
    <div id="status-update-success" class="modal-sect status-update-success">
        <div class="modal-header bb1"><strong>STATUS UPDATED SUCCESSFULLY</strong></div>

        <div class="text-center op6" style="padding: 20px 30px">
            <span class="resMessage"></span>
        </div>
        <div class="btns" style="padding: 0 30px 20px 30px">
            <!-- <a href="#" class="std-btn default" onclick="assignCode({'Type':'Whatsapp','targetInput':'whatsappCodeValue'})">Continue</a> -->
            <a href="#" class="std-btn default" onclick="closeModal({'modalId':'updateModal'})"
                style="border-radius: 4px">DONE</a>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/modals/options.blade.php ENDPATH**/ ?>