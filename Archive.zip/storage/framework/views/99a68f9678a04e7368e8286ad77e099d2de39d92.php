<?php if($draw->campaign->brand_name == 'ShopriteCheckers'): ?>
    <div>
        <div class="modal-sect active" style="width: 400px">
            <div class="modal-header bb1"><strong>REDRAW WINNERS</strong></div>
            <form id="createDrawModal" method="post" action="<?php echo e(route('campaign.redraw.winners',[$draw->id])); ?>" class="col-md-12"
                style="display: flex;padding: 0 25px 25px 25px">
                <?php echo csrf_field(); ?>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="" class="op6 text14">Enter the number of winners to be drawn for Shoprite</label>
                        <div class="input-group">
                            <input name="shoprite_primary_winners" type="number" class="input-error" placeholder="Enter number..." value="">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <label for="" class="op6 text14">Enter Enter the amount of contigency winners</label>
                        <div class="input-group">
                            <input name="shoprite_secondary_winners" type="number" class="input-error" placeholder="Enter number..." value="">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <div class="error" data-name="brand name"></div>
                        <label for="" class="op6 text14">Draw date</label>
                        <div class="input-group">
                            <input name="draw_date" type="dateTime" disabled class="input-error" placeholder="Enter number..." value="<?php echo e($draw->won_at); ?>">
                        </div>

                        <label for="" class="op6 text14">Enter the number of winners to be drawn for Checkers</label>
                        <div class="input-group">
                            <input name="checkers_primary_winners" type="number" class="input-error" placeholder="Enter number..." value="">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <label for="" class="op6 text14">Enter Enter the amount of contigency winners</label>
                        <div class="input-group">
                            <input name="checkers_secondary_winners" type="number" class="input-error" placeholder="Enter number..." value="">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <div class="error" data-name="brand name"></div>
                        <label for="" class="op6 text14">Draw date</label>
                        <div class="input-group">
                            <input name="draw_date" type="dateTime" disabled class="input-error" placeholder="Enter number..." value="<?php echo e($draw->won_at); ?>">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <input type="hidden" name="campaign_id" value="<?php echo e($draw->campaign->id); ?>">
                        <?php if($draw->campaign->epos_campaign_draw->name == 'Weekly draw'): ?>
                            <input type="hidden" name="campaign_type" value="weeklydraw">
                        <?php else: ?>
                            <input type="hidden" name="campaign_type" value="postdraw">
                        <?php endif; ?>
                    </div>
                    <div class="btns" style="padding: 20px 0 0 0">
                        <a href="#" class="std-btn default" onclick="submitForm({'formId':'createDrawModal', 'url':'<?php echo e(route('campaign.redraw.winners')); ?>', 'resView':'status-update-success','modalSect':'status-update-success','method':'POST'})">CREATE DRAW</a>
                        <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})">CANCEL</a>
                    </div>
                </div>
            </form>
        </div>
        <div id="status-update-success" class="modal-sect status-update-success" style="width: 350px">
            <div class="modal-header bb1"><strong>CAMPAIGN DRAW STORED SUCCESSFULLY</strong></div>
    
            <div class="btns" style="padding: 20px 30px 20px 30px">
                <a href="#" class="std-btn default" onclick="closeModal({'modalId':'campaignDrawModal'})" style="border-radius: 4px">DONE</a>
            </div>
        </div>
    </div>
<?php else: ?>
    <div>
        <div class="modal-sect active" style="width: 400px">
            <div class="modal-header bb1"><strong>REDRAW WINNERS</strong></div>
            <form id="createDrawModal" method="post" action="<?php echo e(route('campaign.redraw.winners',[$draw->id])); ?>" class="col-md-12"
                style="display: flex;padding: 0 25px 25px 25px">
                <?php echo csrf_field(); ?>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="" class="op6 text14">Enter the number of winners to be drawn for <?php echo e($draw->title); ?> campaign</label>
                        <div class="input-group">
                            <input name="primary_winners" type="number" class="input-error" placeholder="Enter number..." value="">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <label for="" class="op6 text14">Enter Enter the amount of contigency winners</label>
                        <div class="input-group">
                            <input name="secondary_winners" type="number" class="input-error" placeholder="Enter number..." value="">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <div class="error" data-name="brand name"></div>
                        <label for="" class="op6 text14">Draw date</label>
                        <div class="input-group">
                            <input name="draw_date" type="dateTime" disabled class="input-error" placeholder="Enter number..." value="<?php echo e($draw->won_at); ?>">
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <input type="hidden" name="campaign_id" value="<?php echo e($draw->campaign->id); ?>">
                        <?php if($draw->campaign->epos_campaign_draw->name == 'Weekly draw'): ?>
                            <input type="hidden" name="campaign_type" value="weeklydraw">
                        <?php else: ?>
                            <input type="hidden" name="campaign_type" value="postdraw">
                        <?php endif; ?>
                    </div>
                    <div class="btns" style="padding: 20px 0 0 0">
                        <a href="#" class="std-btn default" onclick="submitForm({'formId':'createDrawModal', 'url':'<?php echo e(route('campaign.redraw.winners')); ?>', 'resView':'status-update-success','modalSect':'status-update-success','method':'POST'})">CREATE DRAW</a>
                        <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})">CANCEL</a>
                    </div>
                </div>
            </form>
        </div>
        <div id="status-update-success" class="modal-sect status-update-success" style="width: 350px">
            <div class="modal-header bb1"><strong>CAMPAIGN DRAW STORED SUCCESSFULLY</strong></div>
    
            <div class="btns" style="padding: 20px 30px 20px 30px">
                <a href="#" class="std-btn default" onclick="closeModal({'modalId':'campaignDrawModal'})" style="border-radius: 4px">DONE</a>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/modals/campaign-redraw.blade.php ENDPATH**/ ?>