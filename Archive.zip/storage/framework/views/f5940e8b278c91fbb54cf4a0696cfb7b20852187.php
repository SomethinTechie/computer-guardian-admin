<div>
    <div class="modal-sect active" style="width: 600px">
        <div class="modal-header bb1"><strong>CAMPAIGN DETAILS</strong></div>
        <?php
            $end_date = \Carbon\Carbon::parse($campaign->end_date);
        ?>
        <?php if($end_date->isPast()): ?>
            <div class="col-md-12" style="text-align: center;width: 100%;padding: 20px">
                Campaign can't be edited after it has been closed.
            </div>

            <div class="btns" style="padding: 0 30px 20px 30px">
                <a href="#" class="std-btn default" style="border-radius: 4px"
                    onclick="closeModal({'modalId':'updateModal'})">CANCEL</a>
            </div>
        <?php else: ?>
            <form id="updateCampaignForm" method="post" action="<?php echo e(route('update.campaign', [$campaign->id])); ?>"
                class="col-md-12" style="display: flex;padding: 25px">
                <?php echo csrf_field(); ?>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="">Campaign ID</label>
                        <div class="input-group">
                            <input name="import_id" type="text" class="input-error"
                                placeholder="Enter import id ..." value="<?php echo e($campaign->import_id); ?>">
                        </div>
                        <div class="error" data-name="brand name"></div>
                    </div>
                    <div class="form-group">
                        <label for="">Brand name</label>
                        <div class="input-group">
                            <input name="brand_name" type="text" class="input-error"
                                placeholder="Enter brand name..." value="<?php echo e($campaign->brand_name); ?>" disabled>
                        </div>
                        <div class="error" data-name="brand name"></div>
                        <label for="">Title</label>
                        <div class="input-group">
                            <input name="title" type="text" class="input-error"
                                placeholder="Enter campaign name..." value="<?php echo e($campaign->title); ?>"
                                oninput="this.value = this.value.replace(/[^a-zA-Z0-9 ]/g, '');">
                        </div>
                        <div class="error" data-name="campaign name"></div>
                    </div>
                    <div class="form-group d-flex-center-left">
                        <div class="col-md-6">
                            <label for="">From</label>
                            <div class="input-group">
                                <input name="start_date" type="date" class="input-error" placeholder="From date..."
                                    value="<?php echo e($campaign->start_date); ?>">
                            </div>
                            <div class="error" data-name="from date"></div>
                        </div>
                        <div class="col-md-6">
                            <label for="">To</label>
                            <div class="input-group">
                                <input name="end_date" type="date" class="input-error" placeholder="To..."
                                    value="<?php echo e($campaign->end_date); ?>">
                            </div>
                            <div class="error" data-name="to date"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Billing Reference</label>
                        <div class="input-group">
                            <input name="billing_reference" type="text" class="input-error"
                                placeholder="Enter billing reference..." value="<?php echo e($campaign->billing_reference); ?>">
                        </div>
                        <div class="error" data-name="brand name"></div>
                    </div>
                    <h6 class="mt-4">Description</h6>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <textarea name="description" id="" cols="30" rows="2" value="<?php echo e($campaign->description); ?>"><?php echo e($campaign->description); ?></textarea>
                            </div>
                            <div class="error" data-name="from date"></div>
                        </div>
                    </div>
                    <div id="whatsappShortcodeValue"></div>
                    <div class="btns" style="padding: 20px 0 0 0">
                        <a href="#" class="std-btn default"
                            onclick="submitForm({'formId':'updateCampaignForm', 'url':'<?php echo e(route('update.campaign', [$campaign->id])); ?>', 'resView':'status-update-success','modalSect':'status-update-success','method':'POST'})">SAVE
                            CHANGES</a>
                        <a href="#" class="std-btn default"
                            onclick="closeModal({'modalId':'updateModal'})">CANCEL</a>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <div id="status-update-success" class="modal-sect status-update-success" style="width: 350px">
        <div class="modal-header bb1"><strong>CAMPAIGN UPDATED SUCCESSFULLY</strong></div>

        <div class="btns" style="padding: 20px 30px 20px 30px">
            <a href="#" class="std-btn default"
                onclick="refreshPage({'url':'<?php echo e(route('campaign.show', [$campaign->id])); ?>','view':'ajax-view','modalId':'updateModal'})"
                style="border-radius: 4px">DONE</a>
        </div>
    </div>
</div>

<script>
    document.querySelectorAll('input').forEach(input => {
        if (input.type !== 'date') {
            input.addEventListener('input', function() {
                this.value = this.value.replace(/[^a-zA-Z0-9 ]/g, '');
            });
        }
    });
</script>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/edit.blade.php ENDPATH**/ ?>