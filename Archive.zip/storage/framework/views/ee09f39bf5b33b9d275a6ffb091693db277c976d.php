<?php $__env->startComponent('mail::message'); ?>

<?php if(App::environment() != 'production'): ?>
    <strong><i>This mail was not sent from the Production server, and therefore is likely a test.</i></strong>
    <br>
<?php endif; ?>
# Campaign Go Live

#Details
## Brand: <?php echo e($data['campaign']->brand_name); ?>

## Campaign name: <?php echo e($data['campaign']->title); ?>

## Campaign dates: <strong>From</strong> <?php echo e(\Carbon\Carbon::parse($data['campaign']->start_date)->format('d F Y')); ?> - <strong>to</strong> <?php echo e(\Carbon\Carbon::parse($data['campaign']->end_date)->format('d F Y')); ?>

## Campaign type: <?php echo e($data['campaign']->epos_campaign_type->name); ?>

## Campaign ID: <?php echo e($data['campaign']->import_id); ?>

## Rainmaker contact: <?php echo e($data['campaign']->user->name); ?> <?php echo e($data['campaign']->user->email); ?>

## Draw Type: <?php echo e($data['campaign']->epos_campaign_draw->name); ?>



<?php $__env->startComponent('mail::button',['url' => $actionUrl]); ?>
    Publish Lpro Campaign
<?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/emails/campaign-confirm-go-live.blade.php ENDPATH**/ ?>