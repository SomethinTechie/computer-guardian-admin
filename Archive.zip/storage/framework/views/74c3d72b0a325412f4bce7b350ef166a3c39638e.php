<div class="overview-card">
    <div class="col-md-3">
        <div class="overview-card-insight">
            <span>
                <i class="bi bi-layers pc"></i><br><br>
                Total Parcels <br><br>
                <h4>0</h4>
            </span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="overview-card-insight">
            <span>
                <i class="bi bi-layers-half pc"></i><br><br>
                Received <br><br>
                <h4>0</h4>
            </span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="overview-card-insight">
            <span>
                <i class="bi bi-layers-fill pc"></i><br><br>
                Completed <br><br>
                <h4>0</h4>
            </span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="overview-card-insight">
            <span>
                <i class="bi bi-check-circle-fill pc"></i><br><br>
                Collected <br><br>
                <h4>0</h4>
            </span>
        </div>
    </div>
</div>
<div class="">
    <div class="header">RECENT ACTIVITY</div>
</div>
<?php /**PATH /Users/mahlatsephokwane/Documents/computer guardian/shoprite-matcha-v2.nosync/resources/views/dashboard.blade.php ENDPATH**/ ?>