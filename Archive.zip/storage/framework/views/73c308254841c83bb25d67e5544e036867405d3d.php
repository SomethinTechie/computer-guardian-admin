<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>