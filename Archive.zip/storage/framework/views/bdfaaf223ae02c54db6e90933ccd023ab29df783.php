<div>
    <div class="modal-sect active" style="width: 400px">
        <div class="modal-header bb1"><strong>EXTEND CAMPAIGN</strong></div>
        <form id="extendCampaignForm" method="post" action="<?php echo e(route('campaign.extend.dates',[$campaign->id])); ?>" class="col-md-12"
            style="display: flex;padding: 0 25px 25px 25px">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
                <div class="form-group">
                    <div class="error" data-name="brand name"></div>
                    <label for="" class="op6 text14">Extention date</label>
                    <div class="input-group">
                        <input type="hidden" name="enddate" value="<?php echo e($campaign->end_date); ?>">
                        <input id="end_date" name="end_date" type="date" class="input-error" value="<?php echo e($campaign->end_date); ?>">
                    </div>
                    <div class="error" data-name="brand name"></div>
                </div>
                <div class="error" data-name="end date"></div>
                <div class="btns" style="padding: 20px 0 0 0">
                    <a href="#" class="std-btn default" onclick="submitForm({'formId':'extendCampaignForm', 'url':'<?php echo e(route('campaign.extend.dates',[$campaign->id])); ?>', 'resView':'status-update-success','modalSect':'status-update-success','method':'POST'})">SAVE EXTENTION</a>
                    <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})">CANCEL</a>
                </div>
            </div>
        </form>
    </div>
    <div id="status-update-success" class="modal-sect status-update-success" style="width: 350px">
        <div class="modal-header bb1"><strong>CAMPAIGN SUCCESSFULLY EXTENDED</strong></div>
        <div class="btns" style="padding: 20px 30px 20px 30px">
            <a href="#" class="std-btn default" onclick="refreshPage({'url':'<?php echo e(route('campaign.show', [$campaign->id])); ?>','view':'ajax-view', 'modalId':'ajaxModal'})" style="border-radius: 4px">DONE</a>
        </div>
    </div>
</div>

<script>
    startDate = document.getElementById('end_date');
    today = new Date().toISOString().split('T')[0];
    startDate.setAttribute('min', today);
</script>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/modals/extend-dates-modal.blade.php ENDPATH**/ ?>