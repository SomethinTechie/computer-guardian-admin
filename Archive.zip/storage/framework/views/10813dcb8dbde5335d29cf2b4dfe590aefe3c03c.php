<div class="col-md-12 d-flex">
    <div class="col-md-12">
        <div class="col-md-12 d-flex">
            <div class="list col-md-12" style="border-right: solid .1px #ddd">
                <div class="header std-padding-x shade space-between" style="background: transparent">
                    <strong>Campaign details</strong>
                    <div class="left">
                        <div class="btn-group" role="group" aria-label="Campaign Actions">
                            <a href="#" class="btn btn btn-default"
                                onclick="openModal({'url':'<?php echo e(route('campaign.extend.dates.modal', [$campaign->id])); ?>','modalId':'ajaxModal','method':'GET'})">
                                <i class="bi bi-calendar2 mr-1"></i>Extend
                            </a>
                            <a href="#" class="btn btn btn-default"
                                onclick="update({'url':'<?php echo e(route('campaign.edit', [$campaign->id])); ?>','modalId':'updateModal'})"><i
                                    class="bi bi-pen mr-1"></i>Edit
                                campaign</a>
                            <?php if($campaign->import_id == 0): ?>
                                <a href="#" class="btn btn btn-default"><i
                                        class="bi bi-x-lg mr-1"></i>Disabled</a>
                            <?php else: ?>
                                <a href="#" id="disable-campaign-button" class="btn btn btn-default" onclick="processUpdate({'status':'Disabled','url':'<?php echo e(route('campaign-update.status', [$campaign->id])); ?>','formId':'disableCampaignForm','buttonId':'disable-campaign-button'})"><i
                                    class="bi bi-pause mr-1"></i>Disable</a>
                                
                            <?php endif; ?>
                            <form id="disableCampaignForm" action="<?php echo e(route('campaign-update.status', [$campaign->id])); ?>"
                                method="post">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Campaign ID:</span>
                        <?php if($campaign->import_id == 0): ?>
                            Disabled
                        <?php else: ?>
                            <?php echo e($campaign->import_id); ?>

                        <?php endif; ?>
                    </p>
                    <p></p>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Title:</span> <?php echo e($campaign->title); ?></p>
                    <p></p>
                </div>
                <div class="list-item no-hover std-padding-x">
                    <p><span class="op6">Prizes: </span>
                        <?php if($campaign->epos_campaign_rewards->count() > 0): ?>
                            <?php $__currentLoopData = $campaign->epos_campaign_rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="ui-tag">
                                    <?php echo e($item->rewards->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            No prizes assigned.
                        <?php endif; ?>
                    </p>
                    <p></p>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Brand: </span> <?php echo e($campaign->brand_name); ?></p>
                    <p></p>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Type: </span> <?php echo e($campaign->epos_campaign_type->name); ?></p>
                    <p></p>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p>
                        <span class="op6">Start date: </span>
                        <?php echo e(\Carbon\Carbon::parse($campaign->start_date)->format('d F Y')); ?>

                    <p>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p>
                        <span class="op6">End date: </span>
                        <?php echo e(\Carbon\Carbon::parse($campaign->end_date)->format('d F Y')); ?>

                    <p>
                </div>

                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Draw: </span> <?php echo e($campaign->epos_campaign_draw->name); ?></p>
                    <p></p>
                </div>

                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Billing reference: </span> <?php echo e($campaign->billing_reference); ?></p>
                    <p></p>
                </div>

                <div class="list-item no-hover space-between std-padding-x">
                    <p><span class="op6">Description:</span></p>
                </div>

                <div class="list-item no-hover space-between std-padding-x bb1" style="padding-top: 0">
                    <p>
                        <?php echo e($campaign->description); ?>

                    </p>
                </div>

                <div class="header std-padding-x shade bb1 space-between" style="background: transparent">
                    <strong>Draw dates</strong>
                    <div class="right">
                        <?php if($campaign->lproslipentries->count() > 0): ?>
                            <div class="btn-group" role="group" aria-label="Campaign Actions">
                                <a href="#" class="btn btn btn-default"
                                    onclick="getView({'url':'<?php echo e(route('generate.winners.csv', [$campaign->id])); ?>','view':'ajax-view'})"><i
                                        class="bi bi-trophy mr-1"></i>View winners</a>
                                <a href="<?php echo e(route('campaign.download.csv', [$campaign->id])); ?>"
                                    class="btn btn btn-default">
                                    <i class="bi bi-download mr-1"></i>Download winners
                                </a>
                            </div>
                        <?php else: ?>
                            No winners available yet.
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if($campaign->lpro_campaign_draw->count() > 0): ?>
                    <table class="bb1">
                        <th>Draw date</th>
                        <th>Winners</th>
                        <th>Contingency</th>
                        <?php if($campaign->epos_campaign_draw->name == 'Weekly draw'): ?>
                            <th style="text-align: right">Actions</th>
                        <?php endif; ?>
                        <?php $__currentLoopData = $campaign->lpro_campaign_draw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $draw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($draw->draw_date)->format('d F Y')); ?></td>
                                <td><?php echo e($draw->primary_winners); ?></td>
                                <td><?php echo e($draw->secondary_winners); ?></td>
                                <td>
                                    <?php if($campaign->epos_campaign_draw->name == 'Weekly draw'): ?>
                                        <a href="#"
                                            onclick="openModal({'modalId':'ajaxModal','title':'DRAW WINNERS','url':'<?php echo e(route('campaign.weekly.draw.edit', [$draw->id])); ?>','method':'GET'})"
                                            class="std-btn-sm default"><i class="bi bi-pen mr-1"></i>Edit winners
                                            count</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php else: ?>
                    <div style="padding: 20px 25px">No draw created yet.</div>
                <?php endif; ?>
                

                <div class="header std-padding-x shade" style="background: transparent">
                    <strong>Campaign manager</strong>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p><span>Name: </span> <?php echo e($campaign->user->name); ?></p>
                </div>
                <div class="list-item no-hover space-between std-padding-x">
                    <p><span>Email: </span> <?php echo e($campaign->user->email); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/show.blade.php ENDPATH**/ ?>