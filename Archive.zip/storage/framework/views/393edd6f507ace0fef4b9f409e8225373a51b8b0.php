<div class="header" style="border-bottom: none;">
    <div class="row mt-3">
        <h5>Campaigns</h5>
    </div>
</div>

<div class="col-md-12 mt-2 std-padding-x">
    <div class="message" style="border: solid .1px #ddd;padding: 5px 10px;border-radius: 6px;width: auto;float:left;background: #eee">Found <?php echo e(count($campaigns)); ?> matching "<?php echo e($title); ?>"</div>
    <div class="scrollview" style="float: left;width: 100%;">
        <?php if(count($campaigns) > 0): ?>
            <table class="mt-4">
                <th>Title</th>
                <th>start date</th>
                <th>End date</th>
                <th>Entries</th>
                <th>Country</th>
                <th>Billing reference</th>
                <th>Campaign ID</th>
                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td onclick="getView({'url':'<?php echo e(route('campaign.show', [$campaign->id])); ?>','view':'ajax-view'})"><?php echo e($campaign->title); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($campaign->start_date)->format('d F Y')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($campaign->end_date)->format('d F Y')); ?></td>
                        <td><?php echo e(count($campaign->lprocompetitionentries)); ?></td>
                        <td class="update-<?php echo e($campaign->id); ?>" style="width: 200px"><?php echo e($campaign->country->title); ?></td>
                        <td><?php echo e($campaign->billing_reference); ?></td>
                        <td><?php echo e($campaign->slug); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php else: ?>
            <p class="mt-3" style="padding: 0"><span>No campaigns found matching your search</span></p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/search-results.blade.php ENDPATH**/ ?>