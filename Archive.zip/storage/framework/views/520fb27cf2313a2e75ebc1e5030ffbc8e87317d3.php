<div class="" style="width: 450px">
    <div class="modal-header bb1">
        <strong>OPEN A TICKET</strong>
    </div>
    <form action="#" style="padding: 20px 30px;">
        <div class="form-group">
            <label for="name">Subject</label>
            <div class="input-group">
                <input type="text" name="name" id="name" class="form-control" placeholder="eg. Technical...">
            </div>
        </div>
        <div class="form-group">
            <label for="name">Customer name</label>
            <div class="input-group">
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter customer name...">
            </div>
        </div>
        <div class="form-group">
            <label for="name">Email Address</label>
            <div class="input-group">
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter email address...">
            </div>
        </div>
        <div class="form-group">
            <label for="name">Mobile number</label>
            <div class="input-group no-borders">
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter mobile number...">
            </div>
        </div>
        <div class="form-group">
            <label for="name">Description / Message</label>
            <div class="input-group border">
                <textarea name="" id="" cols="30" rows="2" placeholder="Enter support message..."></textarea>
            </div>
        </div>
    </form>
    <div class="btns">
        <a href="#" class="std-btn default">ADD</a>
        <a href="#" class="std-btn default" onclick="closeModal({'modalId':'ajaxModal'})">Cancel</a>
    </div>
</div><?php /**PATH /Users/mahlatsephokwane/Documents/computer guardian/shoprite-matcha-v2.nosync/resources/views/support/create.blade.php ENDPATH**/ ?>