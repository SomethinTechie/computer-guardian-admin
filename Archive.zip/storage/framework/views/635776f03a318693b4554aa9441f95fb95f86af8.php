<div class="header space-between" style="border-bottom: none;">
    <h5>Campaigns</h5>
    <h5>ePos portal</h5>
</div>

<div class="col-md-12 mt-2 std-padding-x">

    <div class="message mb-2" style="border: solid .1px #ddd;padding: 10px 20px;border-radius: 6px;background: #eee">
        Found (<?php echo e($total); ?>) total campaigns
        <div class="right">
            <a href="#" onclick="getView({'url':'<?php echo e(route('campaign.create')); ?>','view':'ajax-view'})"
                class="btn btn-default mr-2 btn-sm">Create campaign</a>
            <div class="drop-down-opts-btn mr-2">
                <i class="bi bi-calendar2" style="float: right;margin-right: 5px"></i>
                <span class="drop-down-opts" style="width: auto">
                    <form action="#">
                        <div class="form-group"
                            style="display: flex;align-items: center;justify-content: center;padding-left: 20px">
                            <small>From</small>
                            <div class="input-group" style="border: none">
                                <input id="start-date" type="date"
                                    onchange="getView({'url':'<?php echo e(route('campaign.index')); ?>', 'start_date': this.value, 'view':'ajax-view'})"
                                    value="<?php echo e($start_date); ?>">
                            </div>
                            <small>to</small>
                            <div class="input-group" style="border: none">
                                <input type="date"
                                    onchange="getView({'url':'<?php echo e(route('campaign.index')); ?>', 'end_date': this.value, 'start_date': document.querySelector('#start-date').value, 'view':'ajax-view'})"
                                    value="<?php echo e($end_date); ?>">
                            </div>
                        </div>
                    </form>
                </span>
            </div>
            <div class="drop-down-opts-btn">
                <i class="bi bi-sliders" style="float: right;margin-right: 5px"></i>
                <span class="drop-down-opts dropback">
                    <li onclick="getView({'url':'<?php echo e(route('campaign.index')); ?>','view':'ajax-view'})" class="">All
                        <i class="bi bi-stack"></i></li>
                    <li onclick="getView({'url':'<?php echo e(route('campaign.index', ['filter' => 'Pending'])); ?>','view':'ajax-view'})"
                        class="">Pending <i class="bi bi-calendar2"></i></li>
                    <li onclick="getView({'url':'<?php echo e(route('campaign.index', ['filter' => 'live'])); ?>','view':'ajax-view'})"
                        class="">Live<i class="bi bi-activity"></i></li>
                    <li onclick="getView({'url':'<?php echo e(route('campaign.index', ['filter' => 'closed'])); ?>','view':'ajax-view'})"
                        class="">Closed<i class="bi bi-calendar2-x"></i></li>
                </span>
            </div>
        </div>
    </div>
    <div class="scrollview">
        <?php if(count($campaigns) > 0): ?>
            <table class="">
                <th>Brand name</th>
                <th>Campaign name</th>
                <th>
                    Campaign dates <span style="margin-left: 30px"></span>
                    <?php if($order == 'desc'): ?>
                        <i class="bi bi-arrow-up-circle-fill" onclick="filterByDate()"></i>
                    <?php else: ?>
                        <i class="bi bi-arrow-down-circle-fill" onclick="filterByDate()"></i>
                    <?php endif; ?>
                    <?php echo e($order); ?>

                </th>
                <th>Campaign type</th>
                <th>Status</th>
                <th>Entries</th>
                <th>Shortcode</th>
                <th>Campaign manager</th>
                <th style="text-align: right">Action</th>
                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="link">
                        <td
                            onclick="getView({'url':'<?php echo e(route('campaign.show', [$campaign->id])); ?>','view':'ajax-view'})">
                            <?php echo e($campaign->brand_name); ?></td>
                        <td><?php echo e($campaign->title); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($campaign->start_date)->format('d F Y')); ?> -
                            <?php echo e(\Carbon\Carbon::parse($campaign->end_date)->format('d F Y')); ?>

                            <?php if(count($campaign->extention) > 0): ?>
                                <span class="badge badge-success" style="background: #cc9c00">Extended</span>
                            <?php endif; ?>
                        </td>
                        <td style="width: 200px"><?php echo e($campaign->epos_campaign_draw->name); ?></td>
                        <td class="update-<?php echo e($campaign->id); ?>">
                            <?php
                                $start_date = \Carbon\Carbon::parse($campaign->start_date);
                                $end_date = \Carbon\Carbon::parse($campaign->end_date);
                            ?>
                            <?php if($campaign->status == 'Disabled'): ?>
                                Disabled
                            <?php elseif($start_date->isPast() && $end_date->isPast()): ?>
                                Closed
                            <?php elseif($start_date->isPast() && $end_date->isFuture() && $campaign->is_published == 1): ?>
                                Live
                            <?php elseif($campaign->is_published == 0): ?>
                                Pending
                            <?php elseif($start_date->isFuture() && $campaign->is_published): ?>
                                Approved
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($campaign->lprocompetitionentries->count()); ?></td>
                        <td><?php echo e($campaign->import_id); ?></td>
                        <td><?php echo e($campaign->user->name); ?></td>
                        <td class="drop-down-opts-btn" style="position: relative;width: 50px">
                            <i class="bi bi-three-dots-vertical" style="float: right;margin-right: 5px"></i>
                            <span class="drop-down-opts">
                                <li
                                    onclick="getView({'url':'<?php echo e(route('campaign.show', [$campaign->id])); ?>','view':'ajax-view'})">
                                    View <i class="bi bi-eye mr20"></i> </li>
                                <li
                                    onclick="update({'url':'<?php echo e(route('campaign-update.options', [$campaign->id])); ?>','modalId':'updateModal'})">
                                    Options <i class="bi bi-layers mr20"></i></li>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="row mt-5">
                <?php echo e($campaigns->links('pagination::bootstrap-4')); ?>

            </div>
        <?php else: ?>
            <p class="mt-3" style="padding: 0 20px"><span>No campaigns added yet,</span> <a href="#"
                    onclick="getView({'url':'<?php echo e(route('campaign.create')); ?>','view':'ajax-view'})"
                    style="text-decoration: none"> Add Campaign</a></p>
        <?php endif; ?>
    </div>
</div>

<script>
    document.querySelector('.ajax-view').addEventListener('click', function(event) {

        if (event.target.matches('.pagination a')) {
            event.preventDefault();
            paginate();
        }

    });
</script>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/index.blade.php ENDPATH**/ ?>