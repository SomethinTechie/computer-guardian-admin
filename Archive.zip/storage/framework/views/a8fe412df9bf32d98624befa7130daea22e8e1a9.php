<div class="scrollview" style="height: calc(100vh - 70px)">
    <div class="header space-between" style="border-bottom: none;">
        <h5>Campaign setup</h5>
        <h5>ePOS Portal</h5>
    </div>
    <section id="content">
        <form id="new-campaign-form" action="<?php echo e(route('campaign.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="camp-container col-md-7">
                <div class="campcreate-body">
                    <div class="col-md-12 d-flex">
                        <label style="margin-right: 30px">
                            <input type="radio" data-campaign-brand="Shoprite" name="brand_name" value="Shoprite" />
                            Shoprite
                        </label>
                        <br />
                        <label style="margin-right: 30px">
                            <input type="radio" data-campaign-brand="Checkers" name="brand_name" value="Checkers" />
                            Checkers
                        </label>
                        <br />
                        <label>
                            <input type="radio" name="brand_name" value="ShopriteCheckers" />
                            Shoprite & Checkers
                        </label>
                    </div>
                    <div class="error" data-name="The brand name field is required"></div>
                    <div class='mt-3'></div>
                    <div class="date-campcreate">
                        <p class="op6">Campaign name</p> <input type="text" name="title" class="ui-input"
                            placeholder="Enter campaign title..." />
                    </div>
                    <div class="error" data-name="title"></div>

                    <div class='mt-3'></div>
                    <div class="date-campcreate">
                        <p class="op6">Select campaign type</p>
                    </div>
                    <div class="col-md-12 d-flex">
                        <?php $__currentLoopData = $eposCampaignTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="margin-right: 30px">
                                <input type="radio" name="campaign_type_id" value="<?php echo e($type->id); ?>" />
                                <?php echo e($type->name); ?>

                            </label>
                            <br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="error" data-name="campaign type id"></div>

                    <div class='mt-3'></div>
                    <div class="date-campcreate">
                        <p class="op6">Select draw machanic</p>
                    </div>
                    <div class="col-md-12 d-flex">
                        <?php $__currentLoopData = $eposCampaignDraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $draw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="margin-right: 30px">
                                <input type="radio" data-campaign-draw-type="<?php echo e($draw->name); ?>"
                                    id="campaign_draw_id_<?php echo e($draw->id); ?>" name="campaign_draw_name"
                                    value="<?php echo e($draw->name); ?>" />
                                <?php echo e($draw->name); ?>

                            </label>
                            <br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="error" data-name="draw"></div>

                    <div class='mt-3'></div>
                    <div class="date-campcreate">
                        <p class="op6">Select reward (for XS only, rewards are not fulfilled by YONDER)</p>
                    </div>
                    <div class="col-md-12 d-flex">
                        <?php $__currentLoopData = $eposCampaignRewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="margin-right: 30px">
                                <input type="checkbox" name="rewards[]" value="<?php echo e($reward->id); ?>" />
                                <?php echo e($reward->name); ?>

                            </label>
                            <br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="error" data-name="reward"></div>

                    <div class="date-campcreate d-flex mt-3">
                        <div class="col-md-6">
                            <p class="op6">Start date</p> <input id="start_date" type="date" name="start_date"
                                class="ui-input" />
                        </div>
                        <div class="col-md-6">
                            <p class="op6">End date</p> <input id="end_date" type="date" name="end_date"
                                class="ui-input" />
                        </div>
                    </div>
                    <div id="res-data-container"></div>
                    <div class="form-group d-flex-center-left">
                        <div class="error col-md-6" data-name="start date"></div>
                        <div class="error col-md-6" data-name="end date"></div>
                    </div>

                    <div class="date-campcreate mt-3">
                        <p class="op6">Country code</p>
                        <div class="input-group" style="padding-right: 20px;background: #fff;">
                            <select name="country_id" id="" class="ui-input" value="1"
                                style="border: none!important;outline: none;height: 46px">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="error col-md-6" data-name="country"></div>
                    <div class='mt-3'></div>
                    <div class="single active form-sect">
                        <p class="op6">Billing reference</p> <input type="text" name="billing_reference"
                            class="ui-input" placeholder="Enter billing reference..." />
                    </div>
                    <div class="error col-md-6" data-name="billing ref"></div>
                    <div class="both form-sect d-flex mt-3 mb-3">
                        <div class="col-md-6" style="float: left">
                            <p class="op6">Shoprite billing reference</p> <input type="text"
                                name="shoprite_billing_ref" class="ui-input"
                                placeholder="Enter billing reference..." />
                        </div>
                        <div class="col-md-6" style="float: left">
                            <p class="op6">Checkers billing reference</p> <input type="text"
                                name="checkers_billing_ref" class="ui-input"
                                placeholder="Enter billing reference..." />
                        </div>
                    </div>
                    <div class='mt-3'></div>
                    <div class="date-campcreate">
                        <p class="op6">Description</p>
                        <textarea name="description" id="" cols="30" rows="2" class="ui-input"
                            placeholder="Write campaign description..."></textarea>
                    </div>
                    <div class="error col-md-6" data-name="description"></div>
                    <div class='mt-2'></div>
                    <div class="date-campcreate">
                        <p class="op6">Campaign ID</p> <input type="number" name="import_id" class="ui-input"
                            placeholder="Enter campaign ID..." />
                    </div>
                    <div class="error col-md-6" data-name="import"></div>
                </div>

            </div>
            <div class="camp-container col-md-8">
                <div class="camp-submit mb-3">
                    <a href="#" class="std-btn primary"
                        onclick="submitForm({'formId':'new-campaign-form', 'url':'<?php echo e(route('campaign.store')); ?>','method':'POST'})"
                        style="float: left;width:210px;justify-content: center;">CREATE
                        CAMPAIGN</a>
                </div>
            </div>
        </form>
    </section>
</div>


<script>
    document.querySelector('input[type=radio]').addEventListener('click', toggleCheckbox);

    startDate = document.getElementById('start_date');
    endDate = document.getElementById('end_date');
    campaignTypeRadio = document.querySelector('[data-campaign-draw-type="Weekly draw"]');

    today = new Date().toISOString().split('T')[0];
    startDate.setAttribute('min', today);

    startDate.addEventListener('change', function() {
        let newDate = new Date(startDate.value);
        newDate.setDate(newDate.getDate() + 7);
        let minDate = newDate.toISOString().split('T')[0];
        endDate.setAttribute('min', minDate);
    });

    startDate.addEventListener('change', function() {
        console.log(campaignTypeRadio.checked)
        if (campaignTypeRadio.value == '1') {
            let mondaysCount = countMondays(startDate.value, endDate.value);
            console.log('Mondays count:', mondaysCount);
        }
    });

    endDate.addEventListener('change', function() {
        if (campaignTypeRadio.checked) {

            let checkedBrand = document.querySelector('input[name="brand_name"]:checked');
            console.log(checkedBrand)
            if (!checkedBrand) {
                alert('Please select a brand');
                return;
            }

            let mondaysCount = countMondays(startDate.value, endDate.value);

            openModal({
                'modalId': 'campaignDrawModal',
            });

            let drawDatesSpan = document.getElementById('draw-dates');
            let hiddenInput = document.createElement('input');
            
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'brand_name';
            hiddenInput.value = checkedBrand.value;
            drawDatesSpan.appendChild(hiddenInput);

            let headers = ['DRAW DATES', 'WINNERS AMOUNT', 'CONTIGENCY WINNERS'];

            headers.forEach(function(header) {
                let th = document.createElement('th');
                th.textContent = header;
                drawDatesSpan.appendChild(th);
            });

            mondaysCount.forEach(function(date, index) {
                let tr = document.createElement('tr');

                let td1 = document.createElement('td');
                let input = document.createElement('input');
                let span = document.createElement('span');
                input.type = 'date';
                input.name = 'date' + index;
                input.value = date;
                span.textContent = `Week ${index + 1}`;
                // tr.append(span);
                td1.appendChild(span);
                td1.appendChild(input);
                tr.appendChild(td1);

                console.log(date)

                let td2 = document.createElement('td');
                let input1 = document.createElement('input');
                input1.name = 'primary_winners' + index;
                input1.value = 0
                td2.appendChild(input1);
                tr.appendChild(td2);

                let td3 = document.createElement('td');
                let input2 = document.createElement('input');
                input2.name = 'secondary_winners' + index;
                input2.value = 0
                td3.appendChild(input2);
                tr.appendChild(td3);

                drawDatesSpan.appendChild(tr);
            });
        }
    });

    function countMondays(startDate, endDate) {
        let start = new Date(startDate);
        let end = new Date(endDate);
        let mondaysCount = 0;
        let drawDates = [];

        while (start <= end) {
            if (start.getDay() === 1) { // 1 is Monday
                mondaysCount++;
                console.log('date' + start.toISOString().split('T')[0]);
                drawDates.push(start.toISOString().split('T')[0]);
            }
            start.setDate(start.getDate() + 1);
        }

        console.log(drawDates)

        return drawDates;
    }

    document.querySelectorAll('input').forEach(input => {
        if (input.type !== 'date') {
            input.addEventListener('input', function() {
                this.value = this.value.replace(/[^a-zA-Z0-9 ]/g, '');
            });
        }
    });
</script>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/create.blade.php ENDPATH**/ ?>