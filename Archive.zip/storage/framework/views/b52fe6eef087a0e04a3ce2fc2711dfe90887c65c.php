<div>
    <div class="modal-sect active" style="width: 600px">
        <div class="modal-header bb1"><strong>CAMPAIGN DETAILS</strong></div>
        <form id="updateCampaignForm" method="post" action="" class="col-md-12"
            style="display: flex;padding: 25px">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
                <table>
                    <th>Draw dates</th>
                    <th>Winners</th>
                    <th>Contigency winners <?php echo e(count($drawDates)); ?></th>
                    <?php $__currentLoopData = $drawDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $draw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($draw->date); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="btns" style="padding: 20px 0 0 0">
                    <a href="#" class="std-btn default" onclick="submitForm({'formId':'updateCampaignForm', 'url':'', 'resView':'status-update-success','modalSect':'status-update-success','method':'POST'})">SAVE & CONTINUE</a>
                    <a href="#" class="std-btn default" onclick="closeModal({'modalId':'updateModal'})">CANCEL</a>
                </div>
            </div>
        </form>
    </div>
    <div id="status-update-success" class="modal-sect status-update-success" style="width: 350px">
        <div class="modal-header bb1"><strong>CAMPAIGN UPDATED SUCCESSFULLY</strong></div>

        <div class="btns" style="padding: 20px 30px 20px 30px">
            <a href="#" class="std-btn default" onclick="refreshPage({'url':'','view':'ajax-view'})"
                style="border-radius: 4px">DONE</a>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/modals/add-draw-winners.blade.php ENDPATH**/ ?>