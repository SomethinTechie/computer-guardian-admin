<div class="header" style="border-bottom: none;">
    <div class="row mt-3">
        <h5>Search results <?php echo e($title); ?></h5>
    </div>
</div>

<div class="col-md-12 mt-2 std-padding-x">
    <div class="message"
        style="border: solid .1px #ddd;padding: 5px 10px;border-radius: 6px;width: auto;float:left;background: #eee">
        Found <?php echo e($totalEntries); ?> entries</div>
    <div class="scrollview" style="float: left;width: 100%;">
        <?php if(count($entries) > 0): ?>
            <table class="mt-4">
                <th>Brand</th>
                <th>Hybris ID</th>
                <th>Campaign name</th>
                <th>Campaign dates</th>
                <th>Campaign type</th>
                <th>Entry date</th>
                <th>Winner</th>
                    <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($entry->yomo_profile): ?>
                            <tr>
                                <td>
                                    <?php if($entry->campaign): ?>
                                        <?php echo e($entry->campaign->brand_name); ?>

                                    <?php else: ?>
                                        No campaign associated
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($entry->yomo_profile->yomo_profile_identifiers->unique_identifier); ?></td>
                                <td>
                                    <?php if($entry->campaign): ?>
                                        <?php echo e($entry->campaign->title); ?>

                                    <?php else: ?>
                                        No campaign associated
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($entry->campaign): ?>
                                        <?php echo e(\Carbon\Carbon::parse($entry->campaign->start_date)->format('d F Y')); ?> -
                                        <?php echo e(\Carbon\Carbon::parse($entry->campaign->end_date)->format('d F Y')); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($entry->campaign): ?>
                                        <?php echo e($entry->campaign->epos_campaign_draw->name); ?>

                                    <?php else: ?>
                                        No campaign associated
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($entry->created_at)->format('d F Y')); ?></td>
                                <td>
                                    <?php if($entry->won_at != null): ?>
                                        Yes
                                    <?php else: ?>
                                        No
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="row mt-5">
                <?php echo e($entries->links('pagination::bootstrap-4')); ?>

            </div>
        <?php else: ?>
            <p class="mt-3" style="padding: 0"><span>No entries found matching your search</span></p>
        <?php endif; ?>
    </div>
</div>

<script>
    document.querySelector('.ajax-view').addEventListener('click', function(event) {

        if (event.target.matches('.pagination a')) {
            event.preventDefault();
            paginate();
        }

    });
</script>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/hybris-search-results.blade.php ENDPATH**/ ?>