<div class="header space-between" style="border-bottom: none;">
    <h5>Pending</h5>
    <h5>ePOS Portal</h5>
</div>

<div class="col-md-12 mt-2 std-padding-x">

    <div class="message mb-2" style="border: solid .1px #ddd;padding: 10px 20px;border-radius: 6px;background: #eee">
        Found (<?php echo e($total); ?>) total campaigns
        <div class="right">
            <div class="drop-down-opts-btn">
                <i class="bi bi-calendar2" style="float: right;margin-right: 5px"></i>
                <span class="drop-down-opts" style="width: auto">
                    <form action="#">
                        <div class="form-group"
                            style="display: flex;align-items: center;justify-content: center;padding-left: 20px">
                            <small>From</small>
                            <div class="input-group" style="border: none">
                                <input type="date" placeholder="">
                            </div>
                            <small>to</small>
                            <div class="input-group" style="border: none">
                                <input type="date" placeholder="">
                            </div>
                        </div>
                    </form>
                </span>
            </div>
        </div>
    </div>
    <div class="scrollview">
        <?php if(count($campaigns) > 0): ?>
        <table class="">
            <th>Brand</th>
            <th>Campaign name</th>
            <th>Campaign start date</th>
            <th>Campaign end date</th>
            <th>Campaign type</th>
            <th style="text-align: right">Actions</th>
            <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="link">
                    <td><?php echo e($campaign->brand_name); ?></td>
                    <td><?php echo e($campaign->title); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($campaign->start_date)->format('d F Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($campaign->end_date)->format('d F Y')); ?></td>
                    <td class="update-<?php echo e($campaign->id); ?>" style="width: 200px">
                        <?php echo e($campaign->epos_campaign_type->name); ?></td>
                    <td id="live-status-<?php echo e($campaign->id); ?>">
                        <?php if($campaign->activities->count() == 0): ?>
                        <a onclick="openModal({'modalId':'ajaxModal', 'url':'<?php echo e(route('campaign.confirm.go.live',[$campaign->id])); ?>','method':'GET'})" href="#" class="std-btn-sm primary" style="background: green;color: #fff;">Ready for live</a>
                        <?php else: ?>
                            <a href="#" class="std-btn-sm" style="background: #007bff;color: #fff;pointer-events: none">Go live request sent to YONDER</a>
                        <?php endif; ?>
                        <a href="#" onclick="update({'url':'<?php echo e(route('campaign.edit', [$campaign->id])); ?>','modalId':'updateModal'})" class="std-btn-sm">Edit campaign</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
            <div class="row mt-5">
                <?php echo e($campaigns->links('pagination::bootstrap-4')); ?>

            </div>
        <?php else: ?>
            <p class="mt-3" style="padding: 0 20px"><span>No campaigns added yet,</span> <a href="#"
                    onclick="getView({'url':'<?php echo e(route('campaign.create')); ?>','view':'ajax-view'})"
                    style="text-decoration: none"> Add Campaign</a></p>
        <?php endif; ?>
    </div>
</div>

<script>
    document.querySelector('.ajax-view').addEventListener('click', function(event) {

        if (event.target.matches('.pagination a')) {
            event.preventDefault();
            paginate();
        }

    });
</script>
<?php /**PATH /home/vagrant/Code/shoprite-matcha-v2/resources/views/campaign/pending.blade.php ENDPATH**/ ?>